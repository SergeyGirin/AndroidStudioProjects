package com.example.sergeygirin.alarmer;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Calendar;

public final class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        //Toast.makeText(context, "Alarm worked.", Toast.LENGTH_LONG).show();

        PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0,
                intent, PendingIntent.FLAG_ONE_SHOT);

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + (3 * 60 * 1000), pendingIntent);
        //MainActivity.setAlarm();
        beginSave();
        try {
            mySaveMessage2("alarm");
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void beginSave() {
        if (GlobalVar.getLogFile() == null) {
            GlobalVar.setDir(new File(Environment.getExternalStorageDirectory(), "Pisalka"));
        }

        if (!GlobalVar.getDir().exists()) {
            MainActivity.myShell("ls -l /sdcard/cache/");
            Log.v("GIRIN_app_say", "== myShell == : " +  MainActivity.myShell("ls -l /storage/sdcard0/"));
            File myDir =  GlobalVar.getDir();
            myDir.mkdir();
            Boolean myRead = myDir.setReadable(true,false);
            Boolean myWrite = myDir.setWritable(true,false);
            Boolean myExec = myDir.setExecutable(true,false);
            Log.v("GIRIN_app_say", "== myShell == : " + MainActivity.myShell("ls -l /storage/sdcard0/"));
            GlobalVar.setDir(myDir);

            Log.v("GIRIN_app_say", "Каталог создан");
        }

        if (GlobalVar.getLogFile() == null) {
            Calendar myCalendar = Calendar.getInstance();

            String myLog = "alarmer";

            String sdState = android.os.Environment.getExternalStorageState();
            if (!sdState.equals(android.os.Environment.MEDIA_MOUNTED)) {
                //fileDir = getCacheDir();
            }
            try {
                GlobalVar.setLogFile(GlobalVar.getDir() + "/" + myLog + ".txt");
                FileOutputStream fileOutputStream = new FileOutputStream(GlobalVar.getLogFile(),true);
                Log.v("GIRIN_app_say", "Файл создан :" + GlobalVar.getLogFile());
                BufferedWriter bufferedWriter = new BufferedWriter(
                        new OutputStreamWriter(fileOutputStream, "UTF-8"));
                bufferedWriter.flush();
                bufferedWriter.close();
                fileOutputStream.flush();
                fileOutputStream.close();
            } catch (Exception e) {
                Log.v("GIRIN_app_say", e.getMessage());
            }
        }
    }

    public static void mySaveMessage(String myMessage) throws IOException {
        FileWriter myFileWriter = new FileWriter(GlobalVar.getLogFile(),true);
        Calendar myCalendar = Calendar.getInstance();
        String myLog = String.format("%04d %02d %02d %02d %02d %02d"
                , myCalendar.get(Calendar.YEAR)
                , myCalendar.get(Calendar.MONTH) + 1
                , myCalendar.get(Calendar.DAY_OF_MONTH)
                , myCalendar.get(Calendar.HOUR_OF_DAY)
                , myCalendar.get(Calendar.MINUTE)
                , myCalendar.get(Calendar.SECOND));

        myFileWriter.write(myLog+";"+myMessage+"\n");
        myFileWriter.flush();
        myFileWriter.close();
        //Log.d("GIRIN_app_say", "-=* Записано *=- " + myMessage);
    }

    public static void mySaveMessage2(String myMessage) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream(GlobalVar.getLogFile(),true);
        BufferedWriter bufferedWriter = new BufferedWriter(
                new OutputStreamWriter(fileOutputStream, "UTF-8"));
        Calendar myCalendar = Calendar.getInstance();
        String myLog = String.format("%04d %02d %02d %02d %02d %02d"
                , myCalendar.get(Calendar.YEAR)
                , myCalendar.get(Calendar.MONTH) + 1
                , myCalendar.get(Calendar.DAY_OF_MONTH)
                , myCalendar.get(Calendar.HOUR_OF_DAY)
                , myCalendar.get(Calendar.MINUTE)
                , myCalendar.get(Calendar.SECOND));
        bufferedWriter.append(myLog+";"+myMessage+"\n");
        bufferedWriter.flush();
        bufferedWriter.close();
        fileOutputStream.flush();
        fileOutputStream.close();
        Log.v("GIRIN_app_say", "== myShell == : " + MainActivity.myShell("tail /storage/sdcard0/Pisalka/alarmer.txt"));
    }

}
