package com.example.sergeygirin.alarmer;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;



import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    public static Context myContext;
    public static PendingIntent pendingIntent;
    public static AlarmManager alarmManager;
    //public static Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.v("GIRIN_app_say", "== onCreate == ");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // *********************
        /*
        Intent intent = new Intent(this, AlarmReceiver.class);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 0,
                intent, PendingIntent.FLAG_ONE_SHOT);

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + (10 * 1000), pendingIntent);
        Toast.makeText(this, "Alarm set", Toast.LENGTH_LONG).show();
        */
        // *********************
        myContext = getApplicationContext();

        //intent = new Intent(myContext, AlarmReceiver.class);

        //pendingIntent = PendingIntent.getBroadcast(myContext, 0,
        //        intent, PendingIntent.FLAG_ONE_SHOT);

        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        Log.v("GIRIN_app_say", "== myShell == : " + myShell("ls -l /storage/sdcard0/"));
        Log.v("GIRIN_app_say", "== myShell == : " + myShell("ls -l /system/bin/tail"));
        setAlarm();
        //Log.v("GIRIN_app_say", "== myShell == : " + myShell("dumpsys alarm"));
        //ArrayList<String> res = Util.run("su", "dumpsys alarm");
        //ArrayList<String> res2 = Util.run("/system/bin/su", "dumpsys alarm");


        //Log.v("GIRIN_app_say", "== myShell begin ==\n" + myShell("ls -l") + "== myShell end ==\n");

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public static void setAlarm() {
        Log.v("GIRIN_app_say", "== setAlarm == ");
        Intent intent = new Intent(myContext, AlarmReceiver.class);

        pendingIntent = PendingIntent.getBroadcast(myContext, 0,
                intent, PendingIntent.FLAG_ONE_SHOT);

        alarmManager.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + (20 * 1000), pendingIntent);
        //alarmManager.setInexactRepeating(AlarmManager.ELAPSED_REALTIME_WAKEUP, AlarmManager.INTERVAL_HALF_HOUR, AlarmManager.INTERVAL_HALF_HOUR, alarmIntent);
        Log.v("GIRIN_app_say", "== Alarm set == ");
        Toast.makeText(myContext, "Alarm set", Toast.LENGTH_LONG).show();


    }

    public static String myShell(String command) {
        Log.v("GIRIN_app_say", "== myShell == :" + command);

        StringBuffer output = new StringBuffer();

        Process p;
        try {
            p = Runtime.getRuntime().exec(command);
            p.waitFor();
            BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));

            String line = "";
            while ((line = reader.readLine())!= null) {
                output.append(line + "\n");
            }

        } catch (Exception e) {
            Log.v("GIRIN_app_say", e.getMessage());
            e.printStackTrace();
        }
        String response = output.toString();
        return response;

    }


}
